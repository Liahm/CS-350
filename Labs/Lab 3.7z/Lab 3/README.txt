Not sure how to compile this in tux.
We were told to do it in eclipse/intellij.

To run go to MazeGameCreator and ctr+shift+f10
Select either blue/red/"empty string"
select either large.maze, small.maze, default, or any maze you have.


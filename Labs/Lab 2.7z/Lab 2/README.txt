Couldn't compile in tux because I didn't know how to.
Used Intellij because I was asked to via instructions.

To run go to SimpleMazeGame and click on the green arrow to the left or ctr+shift+f10.
Input either large.maze/small.maze/default.
Dot/player will start on the last room created.